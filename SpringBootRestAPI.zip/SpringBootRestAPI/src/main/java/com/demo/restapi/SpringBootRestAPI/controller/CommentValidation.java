package com.demo.restapi.SpringBootRestAPI.controller;

import java.util.ArrayList;

import io.swagger.annotations.Api;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
//@RequestMapping("/review")
public class CommentValidation {

   @RequestMapping(value="/hello")
   public String hello(){
       return "hello swagger";
   }
    
    
   //@RequestMapping(value = "/readComment", produces = { "text/plain" }, consumes = { "text/plain" }, method = RequestMethod.GET)
   @RequestMapping(value = "/readComment") 
   public String validateComment(@RequestParam("comment") String comment){
	System.out.println("comment is: "+comment);
	String response = "";
	int countofobjwordsincomment = 0;
	
	String parentlibrary = "bad worst annoying irritated waste";
	String[] parentlibinarray = parentlibrary.replaceAll("\"", "").split(" ");
	
	ArrayList<String> listofobjectionablewords = new ArrayList<String>() ;

	for(String eachobjectionableword: parentlibinarray){
	    listofobjectionablewords.add(eachobjectionableword.toLowerCase());
	}
	
	String[] listofwordsincomment = comment.replaceAll("\"","").split(" ");
	System.out.println("length of given comment string array is "+listofwordsincomment.length);
	if(listofwordsincomment.length > 0){
	    for(String eachword: listofwordsincomment){
		System.out.println("each word from comment is: "+eachword);
		if(listofobjectionablewords.contains(eachword)){
		    countofobjwordsincomment++;
		}	
	    }
	}
	System.out.println("objectionable words count: "+countofobjwordsincomment);
	if(countofobjwordsincomment > 0){
	    response = "Comment contains objectionable words";
	}else{
	    response = "canProceed";
	}
	return response;
    }

}
